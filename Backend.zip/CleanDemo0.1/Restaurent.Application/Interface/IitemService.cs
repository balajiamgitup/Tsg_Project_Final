﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Restaurent.Domain.Entities;

namespace Restaurent.Application
{
    public interface IitemService
    {
        Task<IEnumerable<Item>> GetAllItemAsync();

        Task<Item> GetItemAsync(int itemId);

        Task<Item> AddItemAsync(Item item);

        Task<Item> DeleteItemAsync(int itemId);

        Task<Item> UpdateItemAsync(int itemId, Item item);

    }
}
