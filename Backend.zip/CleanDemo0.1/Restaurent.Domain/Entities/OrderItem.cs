﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class OrderItem
    {
        [Key]
        public int orderItemId { get; set; }
        public int quantity { get; set; }
        public int itemId { get; set; }
        public int orderId { get; set; }
        [JsonIgnore]
        [ForeignKey("orderId")]
          public virtual Order order { get; set; }
        [JsonIgnore]
        [ForeignKey("itemId")]
        public virtual Item item { get; set; }
        [JsonIgnore]
        public virtual IEnumerable<Bill> bill { get; set; }
    }
}
