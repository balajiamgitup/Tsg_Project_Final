﻿using NLog.Targets.Wrappers;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository _userRepository)
        {
            this._userRepository = _userRepository;
        }

        public Task AddAsync(User user)
        {
            return _userRepository.AddAsync(user);  
        }

        public Task<User> AuthenticateAsync(string username, string password)
        {
            return _userRepository.AuthenticateAsync(username, password);   
        }

        public Task<User> FindByNameAsync(string username)
        {
          return _userRepository.FindByNameAsync(username);
        }

        public Task<User> RegisterAsync(string username, string email, string password, int RoleId)
        {
       return _userRepository.RegisterAsync(username, email, password, RoleId);
        }
    }
}
