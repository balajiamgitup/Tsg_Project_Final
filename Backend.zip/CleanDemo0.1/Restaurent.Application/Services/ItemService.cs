﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocumentFormat.OpenXml.Drawing.Charts;
using Restaurent.Domain.Entities;

namespace Restaurent.Application
{
    public class ItemService : IitemService

    {

        private readonly ItemRepository  _itemRepository;

        public ItemService(ItemRepository itemRepository)
        {
            this._itemRepository = itemRepository;
        }

        public async Task<Item> AddItemAsync(Item item)
        {
            return await _itemRepository.AddAsync(item);
        }

        public async Task<Item> DeleteItemAsync(int itemId)
        {
            return await _itemRepository.DeleteAsync(itemId);
        }

        public async Task<IEnumerable<Item>> GetAllItemAsync()
        {
            return await _itemRepository.GetAllAsync();
        }

        public async Task<Item> GetItemAsync(int itemId)
        {
            return await _itemRepository.GetAsync(itemId);
        }

        public async Task<Item> UpdateItemAsync(int itemId, Item item)
        {
            return await _itemRepository.UpdateAsync(itemId, item);
        }

      
    }
}
