﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.DTO
{
    public class AddBillRequest
    {

       
        public int totalBill { get; set; }

        public int orderItemId { get; set; }
    }
}
