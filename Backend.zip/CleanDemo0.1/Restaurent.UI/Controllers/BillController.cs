﻿using Microsoft.AspNetCore.Mvc;
using Restaurent.Application;
using Restaurent.Application.Interface;
using Restaurent.Application.Services;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.DTO;

namespace Restaurent.UI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BillController : Controller
    {
        private readonly IBillService billService;
        private Application.Interface.ILogger _logger;
        private readonly IUnitOfWork unitOfWork;
        public BillController(IBillService billService, Application.Interface.ILogger logger)
        {
            this.billService = billService;
            this._logger = logger;

        }
        [HttpGet]
        public async Task<IActionResult> GetAllBillAsync()
        {
            try
            {
                _logger.LogInfo("Fetching all the Bill from the DB");
                var bill = await billService.GetAllBillAsync();
                _logger.LogInfo($"Returning {bill.Count()} Bills.");

                return Ok(bill);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost]
        //[Authorize(Roles = "waiter")]
        public async Task<IActionResult> AddBillAsync([FromBody] AddBillRequest addBillRequest)
        {
           
            try
            {
                _logger.LogInfo($"Adding Orders to DB");
                var billDTO = new AddBillRequest()
                {
                    totalBill = addBillRequest.totalBill,
                    orderItemId = addBillRequest.orderItemId,


                };
              
                var bills = new Bill()
                {
                    // orderId = new Guid(),
                    totalBill = billDTO.totalBill,
                    orderItemId = billDTO.orderItemId,

                };



                bills = await billService.AddBillAsync(bills);


                return Ok(bills);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
