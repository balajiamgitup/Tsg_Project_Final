﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;

namespace Restaurent.Application
{
    public interface ItemRepository : IGenericRepository<Item>
    {
      
    }
}
