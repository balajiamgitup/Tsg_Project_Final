﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.Context
{
    public class RestDbContext:DbContext
    {
        public RestDbContext(DbContextOptions<RestDbContext> options) : base(options)
        {

        }

        public DbSet<Item> item { get; set; }
        public DbSet<Order> orders { get; set; }
        public DbSet<User> users { get;set; }

        public DbSet<Bill> bills { get; set; }

        public DbSet<OrderItem> orderItem { get; set; }
        public DbSet<OrderStatus> orderStatus { get; set; }

      
        public DbSet<Role> roles { get; set; }
        public DbSet<User_Role> userRoles { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User_Role>()
            .HasKey(ur => new { ur.UserId, ur.RoleId });

            modelBuilder.Entity<User_Role>()
                .HasOne(ur => ur.User)
                .WithMany(u => u.UserRoles)
                .OnDelete(DeleteBehavior.NoAction)
                .HasForeignKey(ur => ur.UserId);

            modelBuilder.Entity<User_Role>()
                .HasOne(ur => ur.Role)
                .WithMany(r => r.userRoles)
                .OnDelete(DeleteBehavior.NoAction)
                .HasForeignKey(ur => ur.RoleId);

            // Configure Order-User relationship
            modelBuilder.Entity<Order>()
                .HasOne(o => o.user)
                .WithMany(u => u.Order)
                .OnDelete(DeleteBehavior.NoAction)
                .HasForeignKey(o => o.UserId);

            // Configure Order-OrderStatus relationship
            modelBuilder.Entity<Order>()
                .HasOne(o => o.status)
                .WithMany(os => os.Order)
                .OnDelete(DeleteBehavior.NoAction)
                .HasForeignKey(o => o.statusId);

            // Configure OrderItem-Order relationship
            //modelBuilder.Entity<OrderItem>()
            //    .HasKey(oi => new { oi.orderId, oi.itemId });

            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.order)
                .WithMany(o => o.orderItem)
                .OnDelete(DeleteBehavior.NoAction)
                .HasForeignKey(oi => oi.orderId);

            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.item)
                .WithMany(i => i.orderItem)
                .OnDelete(DeleteBehavior.NoAction)
                .HasForeignKey(oi => oi.itemId);

            // Configure OrderStatus-User relationship
            modelBuilder.Entity<OrderStatus>()
                .HasOne(os => os.user)
                .WithMany(u => u.status)
                .OnDelete(DeleteBehavior.NoAction)
                .HasForeignKey(os => os.UserId);
            //modelBuilder.Entity<User>()
            //    .HasOne(os=>os.Role)
            //    .WithMany(os => os.Users)
            //    .OnDelete(DeleteBehavior.NoAction)
            //    .HasForeignKey(os => os.UserId);
            //        modelBuilder.Entity<Item>(entity =>
            //        {
            //            entity.ToTable("Item");
            //            entity.HasKey(e => e.itemId);
            //            entity.Property(e => e.name)
            //            .IsRequired()
            //            .HasMaxLength(100);
            //            entity.Property(e => e.price)
            //            .IsRequired()
            //            .HasMaxLength(500);
            //            entity.Property(e => e.updatedDate)
            //            .IsRequired()
            //            .HasMaxLength(100);
            //            entity.HasOne(d => d.user)
            //     .WithMany(p => p.Item)
            //     .HasForeignKey(d => d.UserId)
            //     .OnDelete(DeleteBehavior.NoAction)
            //     .HasConstraintName("FK_Item_User");

            //        });
            //        modelBuilder.Entity<Order>(entity =>
            //        {
            //            entity.ToTable("Order");
            //            entity.HasKey(e => e.orderId);
            //            entity.Property(e => e.tablenumber)
            //            .IsRequired()
            //            .HasMaxLength(100);
            //            entity.HasOne(d => d.user)
            //     .WithMany(p => p.Order)
            //     .HasForeignKey(d => d.UserId)
            //     .OnDelete(DeleteBehavior.NoAction)
            //     .HasConstraintName("FK_Order_User");
            //            entity.HasOne(d => d.status)
            //.WithMany(p => p.Order)
            //.HasForeignKey(d => d.statusId)
            //.OnDelete(DeleteBehavior.NoAction)
            //.HasConstraintName("FK_Order_Status");

            //        });

            //        modelBuilder.Entity<OrderItem>(entity =>
            //        {
            //            entity.ToTable("OrderItems");
            //            entity.HasKey(e => e.orderItemId);
            //            entity.Property(e => e.quantity)
            //                .IsRequired()
            //                .HasMaxLength(100);
            //            entity.HasOne(d => d.order)
            //                .WithMany(p => p.orderItem)
            //                .HasForeignKey(d => d.orderId)
            //                .OnDelete(DeleteBehavior.NoAction)
            //                .HasConstraintName("FK_OrderItem_Order");
            //            entity.HasOne(d => d.item)
            //                .WithMany(p => p.orderItem)
            //                .HasForeignKey(d => d.itemId)
            //                .OnDelete(DeleteBehavior.NoAction)
            //                .HasConstraintName("FK_OrderItem_item");
            //        });

            //        modelBuilder.Entity<Bill>(entity =>
            //        {
            //            entity.ToTable("Bill");
            //            entity.HasKey(e => e.billId);
            //            entity.Property(e => e.totalBill)
            //            .IsRequired()
            //            .HasMaxLength(100);
            //            entity.HasOne(d => d.orderItems)
            //     .WithMany(p => p.bill)
            //     .HasForeignKey(d => d.orderItemId)
            //     .OnDelete(DeleteBehavior.NoAction)
            //     .HasConstraintName("FK_Bill_orderItem");

            //        });


            //        modelBuilder.Entity<OrderStatus>(entity =>
            //        {
            //            entity.ToTable("OrderStatus");
            //            entity.HasKey(e => e.statusId);
            //            entity.Property(e => e.statusName)
            //            .IsRequired()
            //            .HasMaxLength(100);
            //            entity.HasOne(d => d.user)
            //     .WithMany(p => p.status)
            //     .HasForeignKey(d => d.UserId)
            //     .OnDelete(DeleteBehavior.NoAction)
            //     .HasConstraintName("FK_status_User");

            //        });
            //        modelBuilder.Entity<User_Role>(entity =>
            //        {
            //            entity.ToTable("UserRoles");
            //            entity.HasKey(e => e.Id);
            //            entity.HasOne(d => d.User)
            //     .WithMany(p => p.UserRoles)
            //     .HasForeignKey(d => d.UserId)
            //     .OnDelete(DeleteBehavior.NoAction)
            //     .HasConstraintName("FK_UserRole_User");
            //            entity.HasOne(d => d.Role)
            //     .WithMany(p => p.userRoles)
            //     .HasForeignKey(d => d.RoleId)
            //     .OnDelete(DeleteBehavior.NoAction)
            //     .HasConstraintName("FK_UserRole_Role");

            //        });
        }
    }



}