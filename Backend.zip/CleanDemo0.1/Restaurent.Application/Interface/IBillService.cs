﻿using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Interface
{
    public interface IBillService
    {
        Task<IEnumerable<Bill>> GetAllBillAsync();

        Task<Bill> GetBillAsync(int Id);

        Task<Bill> AddBillAsync(Bill bill);

        Task<Bill> DeleteBillAsync(int billId);

        Task<Bill> UpdateBillAsync(int billId, Bill bill);
    }
}
