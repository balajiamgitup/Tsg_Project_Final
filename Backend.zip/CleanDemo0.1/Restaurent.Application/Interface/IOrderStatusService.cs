﻿using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Interface
{

    public interface IOrderStatusService
    {
        Task<IEnumerable<OrderStatus>> GetAllOrderStatusAsync();

        Task<OrderStatus> GetOrderStatusAsync(int orderStatusId);

        Task<OrderStatus> AddOrderStatusAsync(OrderStatus orderStatusm);

        Task<OrderStatus> DeleteOrderStatusAsync(int orderStatusId);

        Task<OrderStatus> UpdateOrderStatusAsync(int orderStatusId, OrderStatus rderStatus);
    }
}
