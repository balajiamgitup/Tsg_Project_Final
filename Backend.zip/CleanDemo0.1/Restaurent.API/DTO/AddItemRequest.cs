﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.DTO
{
    public class AddItemRequest
    {
        public string name { get; set; }
        public int price { get; set; }
        public DateTime updatedDate { get; set; }
        public Nullable<int> UserId { get; set; }
    }
}
