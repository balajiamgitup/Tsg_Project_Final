﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Restaurent.Application;
using Restaurent.Application.Interface;
using Restaurent.Application.Services;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.DTO;

namespace Restaurent.UI.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class ItemController : Controller
    {



        private readonly IitemService itemService;
        private Application.Interface.ILogger _logger;
        public ItemController(IitemService itemService, Application.Interface.ILogger logger)
        {
            this.itemService = itemService;
            this._logger = logger;

        }
        [HttpGet]
       [Authorize(Roles = "waiter")]
        public async Task<IActionResult> GetAllItemAsync()
        {
            try
            {
                _logger.LogInfo("Fetching all the Orders from the DB");
                var items = await itemService.GetAllItemAsync();
                _logger.LogInfo($"Returning {items.Count()} Orders.");

                return Ok(items);

            }
           catch (Exception ex)
           {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        [Route("{id:int}")]
        [ActionName("GetItemAsync")]
        //   [Authorize(Roles = "waiter")]
        public async Task<IActionResult> GetItemAsync(int id)
        {

            try
            {
                _logger.LogInfo($"Getting ItemID : {id} item");
                var item= await itemService.GetItemAsync(id);
                if (item == null)
                {
                    //_logger.LogError("ID is not found");
                    return NotFound();
                }
                return Ok(item);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost]
        
        public async Task<IActionResult> AddItemAsync([FromBody] AddItemRequest addItemRequest)
        {

            try
            {
                _logger.LogInfo($"Adding items to DB");
                var items = new AddItemRequest()
                {
                    // orderId = new Guid(),
                    name = addItemRequest.name,
                    price = addItemRequest.price,
                    UserId = addItemRequest.UserId,
                    //updatedDate = new DateTime()


                };

            var item = new Item()
            {
                name = items.name,
                price = items.price,
                UserId = items.UserId,
                updatedDate = new DateTime()
            };

            item = await itemService.AddItemAsync(item);


                return CreatedAtAction(nameof(GetItemAsync), new { id = item.itemId }, items);
            }
            catch (Exception ex)
           {
               _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPut]
       // [Authorize(Roles = "waiter")]
       // [Route("{itemId:int}")]
        public async Task<IActionResult> UpdateItemerAsync(int id, [FromBody] UpdateItemRequest updateItemRequest)
        {
            try
            {
                _logger.LogInfo($"Updating itma with id: {id}");

                var item = await itemService.GetItemAsync(id);
                if (item == null)
                {
                    _logger.LogError($"item with id: {id}, not found");
                    return NotFound();
                }

                item.name = updateItemRequest.name;
                item.price = updateItemRequest.price;
                item.UserId = updateItemRequest.UserId;
                item.updatedDate = DateTime.Now;

                await itemService.UpdateItemAsync(id, item);

                return Ok(item);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete]
      //  [Authorize(Roles = "waiter")]
        [Route("{itemId:int}")]
        public async Task<IActionResult> DeleteItemAsync(int itemId)
        {
            //call Repo
            try
            {

                _logger.LogInfo($"Deleted itemID :  {itemId} Items");

                var item = await itemService.DeleteItemAsync(itemId);

                if (item == null)
                {
                    _logger.LogError($"{itemId} NOT FOUND ");
                    return NotFound();
                }


                return Ok(item);
            }
            catch (Exception ex)
            {

                _logger.LogError($"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
