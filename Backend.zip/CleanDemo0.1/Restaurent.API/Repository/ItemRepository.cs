﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Restaurent.Application;
using Restaurent.Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using Restaurent.Application.Interface;
using System.Security.Cryptography;

namespace Restaurent.Infrastructure.Repository
{
    public class IItemRepository : GenericRepository<Item>, ItemRepository
    {
        public IItemRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}