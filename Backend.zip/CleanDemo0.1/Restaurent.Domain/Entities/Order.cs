﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Text.Json.Serialization;

namespace Restaurent.Domain.Entities
{
    public class Order
    {

        [Key]
        public int? orderId { get; set; }
        public int tablenumber { get; set; }
        public int statusId { get; set; }
        [ForeignKey("User")]
        public int UserId { get; set; }

        public DateTime updatedDate { get; set; }


        [JsonIgnore]
        [ForeignKey("statusId")]
        public virtual OrderStatus status { get; set; }
        [JsonIgnore]  
        public virtual User user { get; set; }
        [JsonIgnore]
        public virtual IEnumerable<OrderItem> orderItem { get; set; }
    }
}
