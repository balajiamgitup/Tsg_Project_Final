﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        [ForeignKey("Role")]
        public int RoleId { get; set; }
        [JsonIgnore]

        
        public virtual Role Role { get; set; }

        [JsonIgnore]
        public virtual IEnumerable<OrderStatus> status { get; set; }
        [JsonIgnore]
        public virtual IEnumerable<Order> Order { get; set; }

        [JsonIgnore]
        public virtual List<User_Role> UserRoles { get; set; }
        [JsonIgnore]
        public virtual IEnumerable<Item> Item { get; set; }
    }
}
