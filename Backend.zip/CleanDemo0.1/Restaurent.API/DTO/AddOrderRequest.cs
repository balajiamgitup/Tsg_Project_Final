﻿using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.DTO
{
    public class AddOrderRequest
    {
        public int tablenumber { get; set; }
        public int statusId { get; set; }
     
        public int UserId { get; set; }

        public DateTime updatedDate { get; set; }

       
       
    }
}
