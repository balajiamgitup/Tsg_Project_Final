﻿using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Services
{
    public class OrderStatusService : IOrderStatusService
    {
        private readonly IOrderStatusRepository _orderStatusRepository;

        public OrderStatusService(IOrderStatusRepository orderStatusRepository)
        {
            this._orderStatusRepository = orderStatusRepository;
        }

        public async Task<OrderStatus> AddOrderStatusAsync(OrderStatus orderStatusm)
        {
          return  await _orderStatusRepository.AddAsync(orderStatusm);
        }

        public async Task<OrderStatus> DeleteOrderStatusAsync(int orderStatusId)
        {
            return await _orderStatusRepository.DeleteAsync(orderStatusId);
        }

        public async Task<IEnumerable<OrderStatus>> GetAllOrderStatusAsync()
        {
           return await _orderStatusRepository.GetAllAsync();
        }

        public async Task<OrderStatus> GetOrderStatusAsync(int orderStatusId)
        {
         return await _orderStatusRepository.GetAsync(orderStatusId);
        }

        public async Task<OrderStatus> UpdateOrderStatusAsync(int orderStatusId, OrderStatus rderStatus)
        {
            return await _orderStatusRepository.UpdateAsync(orderStatusId, rderStatus);
        }
    }
}
