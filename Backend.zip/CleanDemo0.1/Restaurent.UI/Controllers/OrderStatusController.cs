﻿using Microsoft.AspNetCore.Mvc;
using Restaurent.Application.Interface;

namespace Restaurent.UI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderStatusController : Controller
    {
        private readonly IOrderStatusService orderStatusService;
        private Application.Interface.ILogger _logger;
        public OrderStatusController(IOrderStatusService orderStatusService, Application.Interface.ILogger logger)
        {
            this.orderStatusService = orderStatusService;
            this._logger = logger;

        }
        [HttpGet]
        public async Task<IActionResult> GetAllOrderStatusAsync()
        {
            try
            {
                _logger.LogInfo("Fetching all the orderStatus from the DB");
                var orderStatus = await orderStatusService.GetAllOrderStatusAsync();
                _logger.LogInfo($"Returning {orderStatus.Count()} Orders.");

                return Ok(orderStatus);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
