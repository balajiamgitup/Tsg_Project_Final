﻿using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Services
{
    public class BillService : IBillService
    {

        private readonly IBillRepository _billRepository;

        public BillService(IBillRepository billRepository)
        {
            this._billRepository = billRepository;
        }
        public async Task<Bill> AddBillAsync(Bill bill)
        {
            return await _billRepository.AddAsync(bill);
        }

        public async Task<Bill> DeleteBillAsync(int billId)
        {
           return await _billRepository.DeleteAsync(billId);
        }

        public async Task<IEnumerable<Bill>> GetAllBillAsync()
        {
           return await _billRepository.GetAllAsync();
        }

        public async Task<Bill> GetBillAsync(int Id)
        {
         return await _billRepository.GetAsync(Id);
        }

        public async Task<Bill> UpdateBillAsync(int billId, Bill bill)
        {
           return await _billRepository.UpdateAsync(billId, bill);
        }
    }
}
