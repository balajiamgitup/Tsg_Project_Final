﻿using AutoMapper;
using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Office2010.Excel;
using Microsoft.AspNetCore.Mvc;
using Restaurent.Application.Interface;
using Restaurent.Application.Services;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.DTO;
using Restaurent.Infrastructure.Repository;

namespace Restaurent.UI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OrderItemController : Controller
    {
        private Application.Interface.ILogger _logger;

        private readonly IOrderItemService iorderItemService;
        public OrderItemController(IOrderItemService iorderItemService, Application.Interface.ILogger logger)
        {
            this.iorderItemService = iorderItemService;
            this._logger = logger;

        }



        [HttpGet]
        public async Task<IActionResult> GetAllOrderItemsAsync()
        {
            try
            {
                _logger.LogInfo("Fetching all the OrdersItems from the DB");
                var orderItem = await iorderItemService.GetAllOrderItemAsync();
                _logger.LogInfo($"Returning {orderItem.Count()} OrdersItems.");
                return Ok(orderItem);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpGet]
        [Route("{id:int}")]
        [ActionName("GetOrderItemsAsync")]
        public async Task<IActionResult> GetOrderItemsAsync(int id)
        { 
            try
            {
                _logger.LogInfo($"Getting OrdersItemsID : {id} OrdersItems");
                var orderItem = await iorderItemService.GetOrderItemAsync(id);
                if (orderItem == null)
                {
                    _logger.LogError("ID is not found");
                    return NotFound();
                }
     
                return Ok(orderItem);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPost]
        // [Authorize]
        public async Task<IActionResult> AddOrderItemsAsync([FromBody] AddOrderItemRequest addOrderItemRequest)
        {

            try
            {
                _logger.LogInfo($"Adding OrdersItems to DB");
                var orderItemDto = new AddOrderItemRequest()
                {

                    //  orderItemId = addOrderItemRequest.orderItemId,
                    quantity = addOrderItemRequest.quantity,
                    itemId = addOrderItemRequest.itemId,
                    orderId = addOrderItemRequest.orderId


                };
                var orderItem = new OrderItem()
                {

                    //  orderItemId = addOrderItemRequest.orderItemId,
                    quantity = orderItemDto.quantity,
                    itemId = orderItemDto.itemId,
                    orderId = orderItemDto.orderId


                };

                orderItem = await iorderItemService.AddAOrdersync(orderItem);


                return CreatedAtAction(nameof(GetOrderItemsAsync), new { id = orderItem.orderId }, orderItem);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }


        [HttpPut]
        [Route("{orderItemId:int}")]
        public async Task<IActionResult> UpdateOrderItem([FromRoute] int orderItemId, [FromBody]UpdateOrderItemRequest updateOrderItem)
        {


            try
            {
                _logger.LogInfo($"Updating OrdersItems with id: {orderItemId}");

                var orderItem = await iorderItemService.GetOrderItemAsync(orderItemId);
                if (orderItem == null)
                {
                   _logger.LogError($"OrdersItems with id: {orderItemId}, not found");
                    return NotFound();
                }

                orderItem.quantity = updateOrderItem.quantity;
                orderItem.orderId = updateOrderItem.orderId;
                orderItem.itemId = updateOrderItem.itemId;

                await iorderItemService.UpdateOrderItemAsync(orderItemId, orderItem);

                return Ok(orderItem);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }


        }


        [HttpDelete]
        [Route("{orderItemId:int}")]
        public async Task<IActionResult> DeleteOrderItemAsync(int orderItemId)
        {
            try
            {
                _logger.LogInfo($"Deleted OrdersItemsID :  {orderItemId} Orders");
                var orderitem = await iorderItemService.DeleteOrderItemAsync(orderItemId);

                if (orderitem == null)
                {

                    _logger.LogError($"{orderItemId} NOT FOUND ");
                    return NotFound();
                }



                return Ok(orderitem);
            }
            catch (Exception ex)
            {

                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
