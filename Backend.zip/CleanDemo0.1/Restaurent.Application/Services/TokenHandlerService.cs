﻿using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Services
{
    public class TokenHandlerService:ITokenHandlerService
    {
        private readonly ITokenHandler _tokenHandler;

        public TokenHandlerService(ITokenHandler _tokenHandler)
        {
            this._tokenHandler = _tokenHandler;
        }

        public Task<string> CreateTokenAsync(User user)
        {
           return _tokenHandler.CreateTokenAsync(user);
        }
    }
}
