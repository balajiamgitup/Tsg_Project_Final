﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class User_Role
    {
        public int Id { get; set; }

        public int UserId { get; set; }
        public int RoleId { get; set; }
        [JsonIgnore]

        [ForeignKey("UserId")]
        public virtual User User { get; set; }
        [JsonIgnore]
        [ForeignKey("RoleId")]
        public virtual Role Role { get; set; }

    }
}
