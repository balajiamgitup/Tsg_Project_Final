﻿using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Application.Interface
{
    public interface IUserRepository
    {

        Task<User> AuthenticateAsync(string username, string password);
        Task AddAsync(User user);
        Task<User> RegisterAsync(string username, string email, string password, int RoleId);

        Task<User> FindByNameAsync(string username);
    }
}
