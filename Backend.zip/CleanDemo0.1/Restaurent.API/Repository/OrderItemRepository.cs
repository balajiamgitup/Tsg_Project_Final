﻿using Microsoft.EntityFrameworkCore;
using Restaurent.Application.Interface;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.Repository
{
    public class OrderItemRepository : GenericRepository<OrderItem>, IOrderItemRepository
    {

        public OrderItemRepository(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}
