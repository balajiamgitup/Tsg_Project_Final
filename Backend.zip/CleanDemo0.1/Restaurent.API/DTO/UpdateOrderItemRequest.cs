﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.DTO
{
    public  class UpdateOrderItemRequest
    {

        public int quantity { get; set; }
        public int itemId { get; set; }
        public int orderId { get; set; }
    }
}
