﻿using Restaurent.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurent.Infrastructure.DTO
{
    public class UpdateOrderRequest
    {

        public int tablenumber { get; set; }
        public int statusId { get; set; }

        public int UserId { get; set; }

        public DateTime updatedDate { get; set; }


      
    }
}
