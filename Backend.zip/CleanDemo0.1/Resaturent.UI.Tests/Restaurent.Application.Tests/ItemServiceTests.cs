﻿using DocumentFormat.OpenXml.Office.CustomUI;
using Microsoft.EntityFrameworkCore;
using Restaurent.Application;
using Restaurent.Infrastructure.Context;
using Restaurent.Infrastructure.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Item = Restaurent.Domain.Entities.Item;

namespace Resaturent.Tests.Restaurent.Application.Tests
{
    public class ItemServiceTests
    {
        private readonly ItemService _service;
      //  private readonly UnitOfWork _unitOfWork;
        private readonly ItemRepository _repository;

        public ItemServiceTests() {

           var optionsBuilder = new DbContextOptionsBuilder<RestDbContext>()
             .UseInMemoryDatabase(Guid.NewGuid().ToString());
            var unitOfWork =new  UnitOfWork(new RestDbContext(optionsBuilder.Options));
            var itemRepository = _repository;
            _service = new ItemService(itemRepository);
        }
        [Fact]
        public async Task AddItemAsync_ShouldAddItemToDatabase()
        {
            // Arrange
            var item = new Item()
            {
                name = "Idli",
                itemId = 1,
                price = 45,
                UserId=2,
                updatedDate= DateTime.UtcNow,
            };

            // Act
            var addedItem = await _service.AddItemAsync(item);
            var retrievedItem = await _service.GetItemAsync(addedItem.itemId);

            // Assert
            Assert.NotNull(addedItem);
         //   Assert.Equal(item.name, addedItem.name);
          //  Assert.Equal(item.itemId = 1, addedItem.itemId = 1);
          //  Assert.Equal(item.price, addedItem.price);
           // Assert.NotNull(retrievedItem);
           // Assert.Equal(addedItem.itemId, retrievedItem.itemId);
        }

    }
}
