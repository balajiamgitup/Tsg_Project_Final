﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class Item
    {
        [Key]
        public int itemId { get; set; }
        public string name { get; set; }
        public int price { get; set; }
        public DateTime updatedDate { get; set; }
        [ForeignKey("User")]
        public Nullable<int> UserId { get; set; }

         [JsonIgnore]
        
        public virtual User user { get; set; }
        [JsonIgnore]
        public virtual IEnumerable<OrderItem> orderItem { get; set; }

    }
}
