﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Restaurent.Domain.Entities
{
    public class OrderStatus
    {

        [Key]

        public int statusId { get; set; }
        public string statusName { get; set; }
        public int UserId { get; set; }
        [JsonIgnore]

        [ForeignKey("UserId")]
        public virtual User user { get; set; }
        [JsonIgnore]
        public virtual IEnumerable<Order> Order { get; set; }
    }
}
