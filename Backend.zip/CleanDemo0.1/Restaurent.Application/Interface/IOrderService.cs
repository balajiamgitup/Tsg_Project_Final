﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Restaurent.Domain.Entities;
namespace Restaurent.Application.Interface
{
    public interface IOrderService
    {

        Task<Order> AddAsync(Order orders);

        Task<Order> DeleteAsync(int orderId);


        Task<IEnumerable<Order>> GetAllOrderAsync();


        Task<Order> GetOrdeAsync(int orderId);

        Task<Order> UpdateAsync(int orderId, Order orders);
     

    }
}
