﻿using Azure;
using Azure.Core;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Restaurent.Application.Interface;
using Restaurent.Application.Services;
using Restaurent.Domain.Entities;
using Restaurent.Infrastructure.DTO;
using Restaurent.UI.Controllers;
using System.IdentityModel.Tokens.Jwt;

namespace Restaurent.UI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : Controller
    {
        private readonly IUserService _userService;
        private readonly ITokenHandlerService _tokenHandlerService;
        private Application.Interface.ILogger _logger;
        public AuthController(IUserService userService, Application.Interface.ILogger logger, ITokenHandlerService tokenHandlerService)
        {
            this._userService = userService;
            this._tokenHandlerService = tokenHandlerService;
            this._logger = logger;

        }


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> LoginAsync(LoginRequest loginRequest)
        {

            try
            {
              

                var user = await _userService.AuthenticateAsync(loginRequest.name, loginRequest.password);

                if (user == null)
                {
                    throw new Exception("user details are null");
                    return BadRequest(new { message = "Username or password is incorrect" });
                }

                var token = await _tokenHandlerService.CreateTokenAsync(user);

                return Ok(new
                {
                    token = token,
                    Message = "Login Success!",
                    RoleId = user.RoleId,


                });
            }

            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Username) || string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password) || request.RoleId == 0)
                    return BadRequest(new { Message = "Please provide all the required information." });

                var userExists = await _userService.FindByNameAsync(request.Username);
                if (userExists != null)
                    return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User already exists!" });

                var result = await _userService.RegisterAsync(request.Username, request.Email, request.Password, request.RoleId);
                var user = await _userService.AuthenticateAsync(request.Username, request.Password);

                if (result == null)
                    return StatusCode(StatusCodes.Status500InternalServerError, new { Message = "User creation failed! Please check user details and try again." });

                return Ok(new
                {
                    Id = user.UserId,
                    UserName = user.Name,
                    Email = user.Email,
                    Password = request.Password,
                    Message = "User created successfully!"
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Something went wrong: {ex}");
                return StatusCode(500, "Internal server error");
            }
        }
    }
}


